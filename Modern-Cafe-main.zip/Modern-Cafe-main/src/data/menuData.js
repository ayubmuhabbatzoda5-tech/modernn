export const menuData = {
    coffee: [
        { name: 'Classic Espresso', desc: 'Pure Italian tradition, rich and bold flavor', price: '$2.99', icon: '☕' },
        { name: 'Cappuccino Deluxe', desc: 'Velvety microfoam perfection with latte art', price: '$3.99', icon: '☕' },
        { name: 'Caramel Macchiato', desc: 'Sweet harmony of espresso and caramel', price: '$4.49', icon: '☕' },
        { name: 'Cold Brew', desc: 'Smooth and refreshing, 12-hour steeped', price: '$3.99', icon: '🧊' },
        { name: 'Flat White', desc: 'Creamy microfoam with double shot', price: '$4.29', icon: '☕' },
        { name: 'Mocha Latte', desc: 'Rich chocolate and espresso blend', price: '$4.79', icon: '☕' },
        { name: 'Americano', desc: 'Classic espresso with hot water', price: '$3.49', icon: '☕' },
        { name: 'Cortado', desc: 'Equal parts espresso and steamed milk', price: '$3.79', icon: '☕' }
    ],
    pastries: [
        { name: 'Butter Croissant', desc: 'Flaky French pastry, freshly baked daily', price: '$2.49', icon: '🥐' },
        { name: 'Chocolate Éclair', desc: 'Rich chocolate cream filling, decadent', price: '$3.49', icon: '🍫' },
        { name: 'Almond Tart', desc: 'Delicate almond cream with fresh berries', price: '$3.99', icon: '🥧' },
        { name: 'Blueberry Muffin', desc: 'Fresh blueberries, warm and moist', price: '$2.99', icon: '🧁' },
        { name: 'Tiramisu', desc: 'Classic Italian dessert, coffee-infused', price: '$5.99', icon: '🍰' },
        { name: 'Cinnamon Roll', desc: 'Sweet cinnamon swirl with cream glaze', price: '$3.29', icon: '🍞' },
        { name: 'Chocolate Chip Cookie', desc: 'Warm, gooey, and perfectly baked', price: '$2.79', icon: '🍪' },
        { name: 'Apple Pie', desc: 'Homemade with fresh apples and spices', price: '$4.49', icon: '🥧' }
    ],
    meals: [
        { name: 'Avocado Toast', desc: 'Sourdough bread with poached egg and avocado', price: '$7.99', icon: '🥑' },
        { name: 'Caesar Salad', desc: 'Crisp romaine lettuce with parmesan and croutons', price: '$8.99', icon: '🥗' },
        { name: 'Club Sandwich', desc: 'Triple-decker with premium ingredients', price: '$9.99', icon: '🥪' },
        { name: 'Pasta Primavera', desc: 'Fresh seasonal vegetables in creamy sauce', price: '$10.99', icon: '🍝' },
        { name: 'Quiche Lorraine', desc: 'Classic French quiche with bacon and cheese', price: '$8.49', icon: '🥧' },
        { name: 'Beef Panini', desc: 'Grilled beef with vegetables and cheese', price: '$11.99', icon: '🥖' },
        { name: 'Breakfast Bowl', desc: 'Scrambled eggs, bacon, and hash browns', price: '$8.99', icon: '🍳' },
        { name: 'Veggie Wrap', desc: 'Fresh vegetables with hummus and greens', price: '$7.49', icon: '🌯' }
    ],
    drinks: [
        { name: 'Fresh Orange Juice', desc: '100% fresh squeezed oranges', price: '$3.99', icon: '🍊' },
        { name: 'Green Tea', desc: 'Premium Japanese green tea', price: '$2.99', icon: '🍵' },
        { name: 'Iced Tea', desc: 'Refreshing iced tea with lemon', price: '$3.49', icon: '🧊' },
        { name: 'Hot Chocolate', desc: 'Rich and creamy hot chocolate', price: '$4.29', icon: '☕' },
        { name: 'Smoothie Bowl', desc: 'Mixed berries with yogurt and granola', price: '$6.99', icon: '🥤' },
        { name: 'Lemonade', desc: 'Freshly squeezed lemonade', price: '$3.79', icon: '🍋' },
        { name: 'Matcha Latte', desc: 'Premium matcha with steamed milk', price: '$4.99', icon: '🍵' },
        { name: 'Chai Latte', desc: 'Spiced chai with steamed milk', price: '$4.49', icon: '☕' }
    ]
};

