export const teamData = [
    {
        id: 1,
        name: 'Alessandro Rossi',
        role: 'Head Barista & Coffee Master',
        bio: 'With over 15 years of experience in specialty coffee, Alessandro has won multiple international barista championships. He travels the world to source the finest beans and trains our team in the art of perfect extraction.',
        image: '👨‍🍳',
        specialties: ['Espresso', 'Latte Art', 'Coffee Roasting'],
        experience: '15+ years'
    },
    {
        id: 2,
        name: 'Maria Garcia',
        role: 'Pastry Chef',
        bio: 'Maria brings French pastry expertise to our kitchen. Trained in Paris, she creates daily fresh pastries that perfectly complement our coffee. Her innovative flavor combinations have earned us recognition in culinary circles.',
        image: '👩‍🍳',
        specialties: ['French Pastries', 'Desserts', 'Bread Making'],
        experience: '12+ years'
    },
    {
        id: 3,
        name: 'James Chen',
        role: 'Operations Manager',
        bio: 'James ensures everything runs smoothly at Modern Cafe. With a background in hospitality management, he creates the perfect atmosphere for our guests and manages our team with passion and dedication.',
        image: '👔',
        specialties: ['Operations', 'Customer Service', 'Team Management'],
        experience: '10+ years'
    },
    {
        id: 4,
        name: 'Sophie Anderson',
        role: 'Coffee Sourcing Specialist',
        bio: 'Sophie travels to coffee farms worldwide to build direct relationships with farmers. She ensures ethical sourcing and the highest quality beans while supporting sustainable farming practices.',
        image: '🌍',
        specialties: ['Coffee Sourcing', 'Sustainability', 'Farm Relations'],
        experience: '8+ years'
    },
    {
        id: 5,
        name: 'David Kim',
        role: 'Head of Customer Experience',
        bio: 'David creates memorable experiences for every guest. His attention to detail and warm personality make Modern Cafe feel like home. He\'s been with us since day one and knows every regular customer by name.',
        image: '😊',
        specialties: ['Customer Relations', 'Event Planning', 'Community Building'],
        experience: '10+ years'
    },
    {
        id: 6,
        name: 'Emma Thompson',
        role: 'Marketing & Brand Manager',
        bio: 'Emma brings our brand story to life through creative campaigns and community engagement. She manages our social media presence and organizes events that bring our community together.',
        image: '📱',
        specialties: ['Branding', 'Social Media', 'Event Management'],
        experience: '7+ years'
    }
];

