export const blogData = [
    {
        id: 1,
        title: 'The Art of Coffee Roasting: From Bean to Cup',
        excerpt: 'Discover the intricate process of coffee roasting and how it transforms raw beans into the perfect cup of coffee. Learn about different roast levels and their unique flavor profiles.',
        image: '☕',
        date: '2024-01-15',
        author: 'Coffee Master',
        category: 'Coffee Knowledge',
        readTime: '5 min read'
    },
    {
        id: 2,
        title: 'Sustainable Coffee: Our Commitment to the Environment',
        excerpt: 'Learn about our sustainable practices and how we work with farmers worldwide to ensure ethical sourcing and environmental responsibility in every cup.',
        image: '🌱',
        date: '2024-01-10',
        author: 'Sustainability Team',
        category: 'Sustainability',
        readTime: '4 min read'
    },
    {
        id: 3,
        title: 'Perfect Pairings: Coffee and Pastries',
        excerpt: 'Explore the art of pairing different coffee varieties with our exquisite pastries. Discover flavor combinations that elevate your coffee experience to new heights.',
        image: '🥐',
        date: '2024-01-05',
        author: 'Culinary Expert',
        category: 'Food & Drink',
        readTime: '6 min read'
    },
    {
        id: 4,
        title: 'The History of Coffee: A Journey Through Time',
        excerpt: 'Take a fascinating journey through the rich history of coffee, from its discovery in Ethiopia to becoming the world\'s most beloved beverage.',
        image: '📚',
        date: '2023-12-28',
        author: 'History Enthusiast',
        category: 'History',
        readTime: '8 min read'
    },
    {
        id: 5,
        title: 'Home Brewing Tips: Make Perfect Coffee at Home',
        excerpt: 'Master the art of home brewing with our expert tips and techniques. Learn how to create cafe-quality coffee in your own kitchen.',
        image: '🏠',
        date: '2023-12-20',
        author: 'Barista Pro',
        category: 'Tutorials',
        readTime: '7 min read'
    },
    {
        id: 6,
        title: 'Coffee Health Benefits: What Science Says',
        excerpt: 'Explore the scientific research behind coffee\'s health benefits, from antioxidants to improved cognitive function and beyond.',
        image: '💊',
        date: '2023-12-15',
        author: 'Health Expert',
        category: 'Health',
        readTime: '5 min read'
    }
];

