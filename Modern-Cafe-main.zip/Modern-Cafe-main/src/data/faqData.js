export const faqData = [
    {
        id: 1,
        question: 'What makes your coffee special?',
        answer: 'Our coffee is sourced directly from premium farms worldwide, ensuring the highest quality beans. We roast in small batches to maintain freshness and flavor. Our expert baristas are trained in specialty coffee techniques, and we use state-of-the-art equipment to ensure perfect extraction every time.'
    },
    {
        id: 2,
        question: 'Do you offer vegan and gluten-free options?',
        answer: 'Yes! We have a wide selection of vegan and gluten-free options. Our menu includes plant-based milk alternatives (oat, almond, soy, coconut), and many of our pastries are available in gluten-free versions. Please inform our staff about any dietary restrictions, and we\'ll be happy to accommodate you.'
    },
    {
        id: 3,
        question: 'Can I reserve a table for a large group?',
        answer: 'Absolutely! We welcome large groups and private events. For groups of 8 or more, we recommend making a reservation in advance. You can book through our online form or call us directly. We also offer private event spaces for special occasions.'
    },
    {
        id: 4,
        question: 'Do you have WiFi and power outlets?',
        answer: 'Yes, we provide free high-speed WiFi throughout the cafe, and there are power outlets available at most tables. Our space is designed to be comfortable for remote work, with quiet areas and dedicated workspace sections.'
    },
    {
        id: 5,
        question: 'What are your busiest hours?',
        answer: 'Our peak hours are typically weekday mornings (7-10 AM) and weekend brunch hours (9 AM-1 PM). If you prefer a quieter atmosphere, we recommend visiting during weekday afternoons or weekday evenings. We\'re open until 10 PM on weekdays and 11 PM on weekends.'
    },
    {
        id: 6,
        question: 'Do you sell coffee beans for home brewing?',
        answer: 'Yes! We offer a selection of our premium coffee beans for purchase. You can buy whole beans or have them ground to your preferred coarseness. We also offer coffee brewing equipment and accessories. Our baristas can provide recommendations based on your brewing method.'
    },
    {
        id: 7,
        question: 'Are pets allowed?',
        answer: 'Well-behaved pets are welcome in our outdoor seating area. We have water bowls available and even offer special treats for our furry friends. Please keep pets on a leash and ensure they don\'t disturb other guests.'
    },
    {
        id: 8,
        question: 'Do you offer coffee classes or workshops?',
        answer: 'Yes! We host regular coffee tasting workshops, latte art classes, and home brewing tutorials. Check our Events section for upcoming classes. Private group workshops can also be arranged. These sessions are perfect for coffee enthusiasts and beginners alike.'
    }
];

