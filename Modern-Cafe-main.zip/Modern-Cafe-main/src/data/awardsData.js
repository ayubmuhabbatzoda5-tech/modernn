export const awardsData = [
    {
        id: 1,
        title: 'Best Coffee Shop 2024',
        organization: 'Tajikistan Food & Beverage Awards',
        year: '2024',
        description: 'Recognized as the premier coffee destination in Dushanbe for exceptional quality and service.',
        icon: '🏆'
    },
    {
        id: 2,
        title: 'Excellence in Sustainability',
        organization: 'Global Coffee Alliance',
        year: '2023',
        description: 'Awarded for our commitment to ethical sourcing and environmental responsibility.',
        icon: '🌱'
    },
    {
        id: 3,
        title: 'Best Barista Competition Winner',
        organization: 'Central Asia Coffee Championship',
        year: '2023',
        description: 'Our head barista won first place in the regional competition for latte art and espresso quality.',
        icon: '🥇'
    },
    {
        id: 4,
        title: 'Customer Choice Award',
        organization: 'Dushanbe Business Excellence',
        year: '2023',
        description: 'Voted by customers as their favorite coffee shop for three consecutive years.',
        icon: '⭐'
    },
    {
        id: 5,
        title: 'Innovation in Coffee Service',
        organization: 'International Coffee Association',
        year: '2022',
        description: 'Recognized for innovative brewing methods and unique flavor profiles.',
        icon: '💡'
    },
    {
        id: 6,
        title: 'Best Pastry Selection',
        organization: 'Culinary Excellence Awards',
        year: '2022',
        description: 'Acknowledged for our diverse and high-quality pastry offerings.',
        icon: '🥐'
    }
];

