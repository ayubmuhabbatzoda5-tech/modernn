import { useEffect } from 'react';
import { motion } from 'framer-motion';
import ProgressBar from './components/ProgressBar';
import LoadingScreen from './components/LoadingScreen';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import About from './components/About';
import Menu from './components/Menu';
import Gallery from './components/Gallery';
import Events from './components/Events';
import Testimonials from './components/Testimonials';
import Blog from './components/Blog';
import Team from './components/Team';
import Awards from './components/Awards';
import FAQ from './components/FAQ';
import Newsletter from './components/Newsletter';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
    useEffect(() => {
        // Parallax effect for hero background
        const handleScroll = () => {
            const scrolled = window.pageYOffset;
            const heroBg = document.querySelector('.hero-bg');
            if (heroBg && scrolled < window.innerHeight) {
                heroBg.style.transform = `translateY(${scrolled * 0.3}px)`;
            }
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div className="App">
            <ProgressBar />
            <LoadingScreen />
            <Navigation />
            <Hero />
            <About />
            <Menu />
            <Gallery />
            <Events />
            <Testimonials />
            <Blog />
            <Team />
            <Awards />
            <FAQ />
            <Newsletter />
            <Contact />
            <Footer />
        </div>
    );
}

export default App;

