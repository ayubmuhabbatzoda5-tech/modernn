import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const Events = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    const events = [
        {
            date: 'Every Friday • 7:00 PM',
            title: 'Live Jazz Night',
            desc: 'Enjoy smooth jazz performances while sipping your favorite coffee. Free entry for all customers. Experience the perfect blend of music and coffee in an intimate setting.',
            button: 'Learn More →'
        },
        {
            date: 'Every Saturday • 10:00 AM',
            title: 'Coffee Tasting Workshop',
            desc: 'Learn about different coffee origins, brewing methods, and flavor profiles. Perfect for coffee enthusiasts. Limited spots available. Book your place now!',
            button: 'Book Now →'
        },
        {
            date: 'Monthly • First Sunday',
            title: 'Artisan Market',
            desc: 'Local artisans showcase their work. Browse unique crafts while enjoying our special market menu. Support local artists and creators in our community.',
            button: 'View Details →'
        }
    ];

    return (
        <section id="events" className="section events" ref={ref}>
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    Upcoming Events
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Join us for special events, live music, and coffee tasting sessions
                </motion.p>
                <div className="events-grid">
                    {events.map((event, index) => (
                        <EventCard key={index} event={event} index={index} />
                    ))}
                </div>
            </div>
        </section>
    );
};

const EventCard = ({ event, index }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <motion.div
            ref={ref}
            className="event-card fade-in"
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: index * 0.1 }}
            whileHover={{ y: -10 }}
        >
            <div className="event-date">{event.date}</div>
            <h3>{event.title}</h3>
            <p>{event.desc}</p>
            <motion.button
                className="event-button"
                whileHover={{ x: 6 }}
                whileTap={{ scale: 0.95 }}
            >
                {event.button}
            </motion.button>
        </motion.div>
    );
};

export default Events;

