import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const Testimonials = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    const testimonials = [
        {
            stars: '★★★★★',
            text: 'The best coffee in Dushanbe! The atmosphere is cozy and the staff is incredibly friendly. This has become my favorite spot for morning coffee. The pastries are absolutely divine!',
            name: 'Sarah Johnson',
            role: 'Regular Customer',
            avatar: 'SJ'
        },
        {
            stars: '★★★★★',
            text: 'Amazing pastries and perfect brunch options! The quality is outstanding and the presentation is beautiful. Highly recommend to everyone! The service is exceptional and always welcoming.',
            name: 'Michael Chen',
            role: 'Food Blogger',
            avatar: 'MC'
        },
        {
            stars: '★★★★★',
            text: 'Perfect cappuccino and excellent WiFi. This is my go-to spot for remote work. The ambiance is perfect for productivity. The staff always remembers my order!',
            name: 'Emma Rodriguez',
            role: 'Freelancer',
            avatar: 'ER'
        },
        {
            stars: '★★★★★',
            text: 'I\'ve been coming here for years. The consistency in quality is remarkable. Every visit feels special. The coffee is always perfect, and the atmosphere is unmatched.',
            name: 'David Kim',
            role: 'Long-time Customer',
            avatar: 'DK'
        }
    ];

    return (
        <section id="testimonials" className="section testimonials" ref={ref}>
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    What Our Customers Say
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Join hundreds of satisfied customers who love our coffee and atmosphere
                </motion.p>
                <div className="testimonials-grid">
                    {testimonials.map((testimonial, index) => (
                        <TestimonialCard key={index} testimonial={testimonial} index={index} />
                    ))}
                </div>
            </div>
        </section>
    );
};

const TestimonialCard = ({ testimonial, index }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <motion.div
            ref={ref}
            className="testimonial-card fade-in"
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: index * 0.1 }}
            whileHover={{ y: -10 }}
        >
            <div className="testimonial-stars">{testimonial.stars}</div>
            <p className="testimonial-text">{testimonial.text}</p>
            <div className="testimonial-author">
                <div className="testimonial-avatar">{testimonial.avatar}</div>
                <div className="testimonial-info">
                    <h4>{testimonial.name}</h4>
                    <p>{testimonial.role}</p>
                </div>
            </div>
        </motion.div>
    );
};

export default Testimonials;

