import { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { blogData } from '../data/blogData';

const Blog = () => {
    const [selectedCategory, setSelectedCategory] = useState('All');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    const categories = ['All', ...new Set(blogData.map(post => post.category))];

    const filteredPosts = selectedCategory === 'All' 
        ? blogData 
        : blogData.filter(post => post.category === selectedCategory);

    return (
        <section id="blog" className="section blog">
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    Latest News & Stories
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Stay updated with our latest articles, coffee tips, and stories from the world of specialty coffee
                </motion.p>
                
                <motion.div
                    className="blog-categories"
                    initial={{ opacity: 0, y: 30 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.6, delay: 0.4 }}
                >
                    {categories.map((category) => (
                        <motion.button
                            key={category}
                            className={`blog-category ${selectedCategory === category ? 'active' : ''}`}
                            onClick={() => setSelectedCategory(category)}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                        >
                            {category}
                        </motion.button>
                    ))}
                </motion.div>

                <div className="blog-grid">
                    {filteredPosts.map((post, index) => (
                        <BlogCard key={post.id} post={post} index={index} />
                    ))}
                </div>
            </div>
        </section>
    );
};

const BlogCard = ({ post, index }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <motion.article
            ref={ref}
            className="blog-card fade-in"
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ y: -12, scale: 1.02 }}
        >
            <div className="blog-image">{post.image}</div>
            <div className="blog-content">
                <div className="blog-meta">
                    <span className="blog-category-tag">{post.category}</span>
                    <span className="blog-date">{new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    <span className="blog-read-time">{post.readTime}</span>
                </div>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <div className="blog-footer">
                    <span className="blog-author">By {post.author}</span>
                    <motion.button
                        className="blog-read-more"
                        whileHover={{ x: 6 }}
                        whileTap={{ scale: 0.95 }}
                    >
                        Read More →
                    </motion.button>
                </div>
            </div>
        </motion.article>
    );
};

export default Blog;

