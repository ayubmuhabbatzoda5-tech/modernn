import { motion } from 'framer-motion';

const Footer = () => {
    const scrollToSection = (id) => {
        const element = document.getElementById(id);
        if (element) {
            const offsetTop = element.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    };

    return (
        <footer>
            <div className="footer-content">
                <div className="footer-top">
                    <motion.div
                        className="footer-section"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.6 }}
                    >
                        <h3>Modern Cafe</h3>
                        <p>Where every cup tells a story. Experience the finest coffee and cuisine in the heart of Dushanbe.</p>
                        <div className="social-links">
                            {['📘', '📷', '🐦', '📧'].map((icon, index) => (
                                <motion.div
                                    key={index}
                                    className="social-link"
                                    whileHover={{ y: -6, rotate: 5 }}
                                    whileTap={{ scale: 0.9 }}
                                >
                                    {icon}
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>
                    <motion.div
                        className="footer-section"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.6, delay: 0.1 }}
                    >
                        <h3>Quick Links</h3>
                        <p><a href="#about" onClick={(e) => { e.preventDefault(); scrollToSection('about'); }}>About Us</a></p>
                        <p><a href="#menu" onClick={(e) => { e.preventDefault(); scrollToSection('menu'); }}>Our Menu</a></p>
                        <p><a href="#events" onClick={(e) => { e.preventDefault(); scrollToSection('events'); }}>Events</a></p>
                        <p><a href="#contact" onClick={(e) => { e.preventDefault(); scrollToSection('contact'); }}>Contact</a></p>
                    </motion.div>
                    <motion.div
                        className="footer-section"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.6, delay: 0.2 }}
                    >
                        <h3>Services</h3>
                        <p><a href="#menu" onClick={(e) => { e.preventDefault(); scrollToSection('menu'); }}>Coffee</a></p>
                        <p><a href="#menu" onClick={(e) => { e.preventDefault(); scrollToSection('menu'); }}>Pastries</a></p>
                        <p><a href="#menu" onClick={(e) => { e.preventDefault(); scrollToSection('menu'); }}>Meals</a></p>
                        <p><a href="#events" onClick={(e) => { e.preventDefault(); scrollToSection('events'); }}>Events</a></p>
                    </motion.div>
                    <motion.div
                        className="footer-section"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.6, delay: 0.3 }}
                    >
                        <h3>Contact Info</h3>
                        <p>123 Rudaki Avenue</p>
                        <p>Dushanbe, Tajikistan</p>
                        <p>+992 123 456 789</p>
                        <p>info@moderncafe.tj</p>
                    </motion.div>
                </div>
                <div className="footer-bottom">
                    <p>© 2024 Modern Cafe. All rights reserved. | Crafted with ❤️ and ☕</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;

