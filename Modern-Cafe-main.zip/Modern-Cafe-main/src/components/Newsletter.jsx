import { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const Newsletter = () => {
    const [email, setEmail] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [subscribed, setSubscribed] = useState(false);
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.3 });

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));

        setSubscribed(true);
        setEmail('');
        setIsSubmitting(false);

        setTimeout(() => setSubscribed(false), 5000);
    };

    return (
        <section className="newsletter-section">
            <div className="container">
                <motion.div
                    ref={ref}
                    className="newsletter-content"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    <motion.h2
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={isInView ? { opacity: 1, scale: 1 } : {}}
                        transition={{ duration: 0.6, delay: 0.2 }}
                    >
                        Stay Connected
                    </motion.h2>
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={isInView ? { opacity: 1, y: 0 } : {}}
                        transition={{ duration: 0.6, delay: 0.4 }}
                    >
                        Subscribe to our newsletter for exclusive offers, coffee tips, and event updates
                    </motion.p>
                    <motion.form
                        onSubmit={handleSubmit}
                        initial={{ opacity: 0, y: 20 }}
                        animate={isInView ? { opacity: 1, y: 0 } : {}}
                        transition={{ duration: 0.6, delay: 0.6 }}
                    >
                        <div className="newsletter-input-group">
                            <input
                                type="email"
                                placeholder="Enter your email address"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                                disabled={isSubmitting || subscribed}
                            />
                            <motion.button
                                type="submit"
                                disabled={isSubmitting || subscribed}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                {subscribed ? '✓ Subscribed!' : isSubmitting ? 'Subscribing...' : 'Subscribe'}
                            </motion.button>
                        </div>
                        {subscribed && (
                            <motion.p
                                className="newsletter-success"
                                initial={{ opacity: 0, y: -10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0 }}
                            >
                                Thank you for subscribing! Check your inbox for a welcome email.
                            </motion.p>
                        )}
                    </motion.form>
                </motion.div>
            </div>
        </section>
    );
};

export default Newsletter;

