import { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const Contact = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <section id="contact" className="section contact" ref={ref}>
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    Visit Us
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    We'd love to welcome you to our cafe. Reserve your table today!
                </motion.p>
                <div className="contact-grid">
                    <ContactInfo />
                    <ContactForm />
                </div>
            </div>
        </section>
    );
};

const ContactInfo = () => {
    const contactItems = [
        {
            icon: (
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
                    <circle cx="12" cy="10" r="3"></circle>
                </svg>
            ),
            title: 'Location',
            content: '123 Rudaki Avenue<br>Dushanbe, Tajikistan<br>Near City Center'
        },
        {
            icon: (
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
            ),
            title: 'Opening Hours',
            content: 'Monday - Friday: 7:00 AM - 10:00 PM<br>Saturday - Sunday: 8:00 AM - 11:00 PM<br>Holidays: 9:00 AM - 9:00 PM'
        },
        {
            icon: (
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
            ),
            title: 'Contact',
            content: 'Phone: +992 123 456 789<br>Email: info@moderncafe.tj<br>WhatsApp: +992 123 456 789'
        }
    ];

    return (
        <div className="contact-info">
            {contactItems.map((item, index) => (
                <motion.div
                    key={index}
                    className="contact-item"
                    initial={{ opacity: 0, x: -40 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ x: 10 }}
                >
                    <motion.div
                        className="contact-icon"
                        whileHover={{ scale: 1.1, rotate: 5 }}
                    >
                        {item.icon}
                    </motion.div>
                    <div>
                        <h3>{item.title}</h3>
                        <p dangerouslySetInnerHTML={{ __html: item.content }} />
                    </div>
                </motion.div>
            ))}
        </div>
    );
};

const ContactForm = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        date: '',
        time: '',
        guests: '',
        message: ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));

        alert('✅ Thank you for your reservation! We will contact you shortly to confirm your booking.');
        setFormData({
            name: '',
            email: '',
            phone: '',
            date: '',
            time: '',
            guests: '',
            message: ''
        });
        setIsSubmitting(false);
    };

    const today = new Date().toISOString().split('T')[0];

    return (
        <motion.div
            className="contact-form"
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6 }}
        >
            <h3 style={{ fontSize: '36px', fontWeight: 900, marginBottom: '40px', letterSpacing: '-0.03em' }}>
                Reserve a Table
            </h3>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="name">Your Name</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        required
                        placeholder="Enter your full name"
                        value={formData.name}
                        onChange={handleChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="email">Email Address</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        placeholder="your.email@example.com"
                        value={formData.email}
                        onChange={handleChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="phone">Phone Number</label>
                    <input
                        type="tel"
                        id="phone"
                        name="phone"
                        required
                        placeholder="+992 123 456 789"
                        value={formData.phone}
                        onChange={handleChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="date">Preferred Date</label>
                    <input
                        type="date"
                        id="date"
                        name="date"
                        required
                        min={today}
                        value={formData.date}
                        onChange={handleChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="time">Preferred Time</label>
                    <input
                        type="time"
                        id="time"
                        name="time"
                        required
                        value={formData.time}
                        onChange={handleChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="guests">Number of Guests</label>
                    <select
                        id="guests"
                        name="guests"
                        required
                        value={formData.guests}
                        onChange={handleChange}
                    >
                        <option value="">Select number of guests</option>
                        <option value="1">1 Person</option>
                        <option value="2">2 People</option>
                        <option value="3">3 People</option>
                        <option value="4">4 People</option>
                        <option value="5">5 People</option>
                        <option value="6+">6+ People</option>
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="message">Special Requests</label>
                    <textarea
                        id="message"
                        name="message"
                        placeholder="Any special requests, dietary requirements, or occasion details..."
                        value={formData.message}
                        onChange={handleChange}
                    />
                </div>
                <motion.button
                    type="submit"
                    className="btn-primary"
                    style={{ width: '100%', marginTop: '12px', padding: '18px' }}
                    disabled={isSubmitting}
                    whileHover={{ y: -4 }}
                    whileTap={{ scale: 0.98 }}
                >
                    {isSubmitting ? 'Booking...' : 'Book Now'}
                </motion.button>
            </form>
        </motion.div>
    );
};

export default Contact;

