import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const Hero = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.3 });

    const scrollToSection = (id) => {
        const element = document.getElementById(id);
        if (element) {
            const offsetTop = element.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    };

    const stats = [
        { number: 500, label: 'Happy Customers', suffix: '+' },
        { number: 50, label: 'Menu Items', suffix: '+' },
        { number: 5, label: 'Average Rating', suffix: '★' },
        { number: 10, label: 'Years Experience', suffix: '+' }
    ];

    return (
        <section id="hero" className="hero" ref={ref}>
            <div className="hero-bg"></div>
            <div className="hero-content">
                <motion.div
                    className="hero-badge"
                    initial={{ opacity: 0, y: -30 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    ✨ Premium Coffee Experience
                </motion.div>
                <motion.h1
                    className="hero-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 1, delay: 0.2 }}
                >
                    Where Every Cup<br />
                    <span className="highlight">Tells a Story</span>
                </motion.h1>
                <motion.p
                    className="hero-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 1, delay: 0.4 }}
                >
                    Experience the finest artisan coffee, freshly baked pastries, and gourmet cuisine 
                    in an elegant atmosphere. Perfect for business meetings, creative work, or simply 
                    savoring a moment of peace.
                </motion.p>
                <motion.div
                    className="hero-buttons"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 1, delay: 0.6 }}
                >
                    <motion.a
                        href="#menu"
                        className="btn-primary"
                        onClick={(e) => { e.preventDefault(); scrollToSection('menu'); }}
                        whileHover={{ y: -4 }}
                        whileTap={{ scale: 0.98 }}
                    >
                        Explore Menu
                    </motion.a>
                    <motion.a
                        href="#contact"
                        className="btn-secondary"
                        onClick={(e) => { e.preventDefault(); scrollToSection('contact'); }}
                        whileHover={{ y: -4 }}
                        whileTap={{ scale: 0.98 }}
                    >
                        Reserve Table
                    </motion.a>
                    <motion.a
                        href="#gallery"
                        className="btn-secondary"
                        onClick={(e) => { e.preventDefault(); scrollToSection('gallery'); }}
                        whileHover={{ y: -4 }}
                        whileTap={{ scale: 0.98 }}
                    >
                        View Gallery
                    </motion.a>
                </motion.div>
                <motion.div
                    className="hero-stats"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 1, delay: 0.8 }}
                >
                    {stats.map((stat, index) => (
                        <StatItem key={index} stat={stat} delay={index * 0.1} />
                    ))}
                </motion.div>
            </div>
            <motion.div
                className="scroll-indicator"
                onClick={() => scrollToSection('about')}
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 2.5, repeat: Infinity }}
            >
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </motion.div>
        </section>
    );
};

const StatItem = ({ stat, delay }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, threshold: 0.5 });

    return (
        <motion.div
            ref={ref}
            className="stat-item"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.5, delay }}
            whileHover={{ y: -10, scale: 1.03 }}
        >
            <motion.div
                className="stat-number"
                initial={{ opacity: 0 }}
                animate={isInView ? { opacity: 1 } : {}}
            >
                {isInView && <Counter target={stat.number} suffix={stat.suffix} />}
            </motion.div>
            <div className="stat-label">{stat.label}</div>
        </motion.div>
    );
};

const Counter = ({ target, suffix }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        const duration = 2000;
        const steps = 60;
        const increment = target / steps;
        let current = 0;

        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                setCount(target);
                clearInterval(timer);
            } else {
                setCount(Math.floor(current));
            }
        }, duration / steps);

        return () => clearInterval(timer);
    }, [target]);

    return <>{count}{suffix}</>;
};

export default Hero;

