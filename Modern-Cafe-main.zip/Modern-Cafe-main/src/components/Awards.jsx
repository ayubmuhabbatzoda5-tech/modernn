import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { awardsData } from '../data/awardsData';

const Awards = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <section id="awards" className="section awards">
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    Awards & Recognition
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Our commitment to excellence has been recognized by industry leaders and our valued customers
                </motion.p>
                <div className="awards-grid">
                    {awardsData.map((award, index) => (
                        <AwardCard key={award.id} award={award} index={index} />
                    ))}
                </div>
            </div>
        </section>
    );
};

const AwardCard = ({ award, index }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <motion.div
            ref={ref}
            className="award-card fade-in"
            initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
            animate={isInView ? { opacity: 1, scale: 1, rotate: 0 } : {}}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ y: -10, rotate: 2, scale: 1.05 }}
        >
            <motion.div
                className="award-icon"
                animate={{ 
                    rotate: [0, 10, -10, 0],
                    scale: [1, 1.1, 1]
                }}
                transition={{ 
                    duration: 2,
                    repeat: Infinity,
                    repeatDelay: 3
                }}
            >
                {award.icon}
            </motion.div>
            <h3>{award.title}</h3>
            <p className="award-org">{award.organization}</p>
            <p className="award-year">{award.year}</p>
            <p className="award-desc">{award.description}</p>
        </motion.div>
    );
};

export default Awards;

