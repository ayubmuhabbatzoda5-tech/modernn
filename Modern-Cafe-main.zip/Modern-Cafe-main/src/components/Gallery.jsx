import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const Gallery = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    const galleryItems = [
        { icon: '☕', title: 'Artisan Coffee', desc: 'Handcrafted with precision' },
        { icon: '🥐', title: 'Fresh Pastries', desc: 'Baked daily with love' },
        { icon: '🍰', title: 'Gourmet Desserts', desc: 'Sweet moments await' },
        { icon: '🌿', title: 'Cozy Ambiance', desc: 'Perfect for relaxation' },
        { icon: '☕', title: 'Latte Art', desc: 'Beautifully presented' },
        { icon: '🥖', title: 'Fresh Bread', desc: 'Artisan quality' },
        { icon: '🍵', title: 'Specialty Teas', desc: 'Curated selection' },
        { icon: '🎨', title: 'Modern Design', desc: 'Elegant spaces' },
        { icon: '🌟', title: 'Premium Quality', desc: 'Excellence in every detail' }
    ];

    return (
        <section id="gallery" className="section gallery" ref={ref}>
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    Gallery
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Take a visual journey through our beautiful space and delicious creations
                </motion.p>
                <div className="gallery-grid">
                    {galleryItems.map((item, index) => (
                        <GalleryItem key={index} item={item} index={index} />
                    ))}
                </div>
            </div>
        </section>
    );
};

const GalleryItem = ({ item, index }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });
    const [isHovered, setIsHovered] = useState(false);

    return (
        <motion.div
            ref={ref}
            className="gallery-item fade-in"
            initial={{ opacity: 0, scale: 0.8, rotateY: -15 }}
            animate={isInView ? { opacity: 1, scale: 1, rotateY: 0 } : {}}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ scale: 1.08, rotateY: 5, z: 50 }}
            onHoverStart={() => setIsHovered(true)}
            onHoverEnd={() => setIsHovered(false)}
            style={{ perspective: 1000 }}
        >
            <motion.div
                className="gallery-placeholder"
                animate={isHovered ? { scale: 1.1, rotate: 5 } : { scale: 1, rotate: 0 }}
                transition={{ duration: 0.3 }}
            >
                {item.icon}
            </motion.div>
            <AnimatePresence>
                {isHovered && (
                    <motion.div
                        className="gallery-overlay"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 20 }}
                        transition={{ duration: 0.3 }}
                    >
                        <h4>{item.title}</h4>
                        <p>{item.desc}</p>
                    </motion.div>
                )}
            </AnimatePresence>
        </motion.div>
    );
};

export default Gallery;

