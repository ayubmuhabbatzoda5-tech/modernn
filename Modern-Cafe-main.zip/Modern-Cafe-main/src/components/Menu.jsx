import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { menuData } from '../data/menuData';

const Menu = () => {
    const [activeCategory, setActiveCategory] = useState('coffee');
    const [searchQuery, setSearchQuery] = useState('');
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    const categories = [
        { id: 'coffee', label: '☕ Coffee' },
        { id: 'pastries', label: '🥐 Pastries' },
        { id: 'meals', label: '🍽️ Meals' },
        { id: 'drinks', label: '🥤 Drinks' }
    ];

    const filteredItems = menuData[activeCategory].filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.desc.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <section id="menu" className="section menu" ref={ref}>
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    Our Menu
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Artisan coffee, fresh pastries, and gourmet dishes crafted with care and passion
                </motion.p>
                <motion.div
                    className="menu-search"
                    initial={{ opacity: 0, y: 30 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.6, delay: 0.4 }}
                >
                    <input
                        type="text"
                        placeholder="🔍 Search menu items..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </motion.div>
                <div className="menu-tabs">
                    {categories.map((category) => (
                        <motion.button
                            key={category.id}
                            className={`menu-tab ${activeCategory === category.id ? 'active' : ''}`}
                            onClick={() => setActiveCategory(category.id)}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                        >
                            {category.label}
                        </motion.button>
                    ))}
                </div>
                <AnimatePresence mode="wait">
                    <motion.div
                        key={activeCategory}
                        className="menu-grid"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.3 }}
                    >
                        {filteredItems.length > 0 ? (
                            filteredItems.map((item, index) => (
                                <MenuItem key={index} item={item} index={index} />
                            ))
                        ) : (
                            <motion.div
                                className="menu-empty"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                            >
                                <p>No items found matching "{searchQuery}"</p>
                            </motion.div>
                        )}
                    </motion.div>
                </AnimatePresence>
            </div>
        </section>
    );
};

const MenuItem = ({ item, index }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <motion.div
            ref={ref}
            className="menu-item fade-in"
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: index * 0.06 }}
            whileHover={{ y: -14, scale: 1.02 }}
        >
            <div className="menu-item-image">{item.icon}</div>
            <div className="menu-item-content">
                <h3>{item.name}</h3>
                <p>{item.desc}</p>
                <div className="menu-item-price">{item.price}</div>
            </div>
        </motion.div>
    );
};

export default Menu;

