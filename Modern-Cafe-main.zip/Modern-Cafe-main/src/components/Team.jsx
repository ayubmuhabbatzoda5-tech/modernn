import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { teamData } from '../data/teamData';

const Team = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <section id="team" className="section team">
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    Meet Our Team
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Passionate professionals dedicated to creating exceptional coffee experiences. 
                    Our team brings years of expertise and genuine care to every cup we serve.
                </motion.p>
                <div className="team-grid">
                    {teamData.map((member, index) => (
                        <TeamMember key={member.id} member={member} index={index} />
                    ))}
                </div>
            </div>
        </section>
    );
};

const TeamMember = ({ member, index }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.3 });

    return (
        <motion.div
            ref={ref}
            className="team-card fade-in"
            initial={{ opacity: 0, y: 40, rotateY: -15 }}
            animate={isInView ? { opacity: 1, y: 0, rotateY: 0 } : {}}
            transition={{ duration: 0.8, delay: index * 0.1 }}
            whileHover={{ y: -15, scale: 1.03, rotateY: 5 }}
        >
            <motion.div
                className="team-avatar"
                whileHover={{ scale: 1.1, rotate: 5 }}
            >
                {member.image}
            </motion.div>
            <div className="team-info">
                <h3>{member.name}</h3>
                <p className="team-role">{member.role}</p>
                <p className="team-experience">{member.experience} Experience</p>
                <p className="team-bio">{member.bio}</p>
                <div className="team-specialties">
                    {member.specialties.map((specialty, idx) => (
                        <span key={idx} className="specialty-tag">{specialty}</span>
                    ))}
                </div>
            </div>
        </motion.div>
    );
};

export default Team;

