import { useScrollProgress } from '../hooks/useScrollProgress';
import { motion } from 'framer-motion';

const ProgressBar = () => {
    const scrollProgress = useScrollProgress();

    return (
        <motion.div
            className="progress-bar"
            style={{
                transform: `scaleX(${scrollProgress / 100})`,
                transformOrigin: 'left'
            }}
        />
    );
};

export default ProgressBar;

