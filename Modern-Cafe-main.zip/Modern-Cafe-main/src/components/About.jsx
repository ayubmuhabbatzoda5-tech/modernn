import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const About = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    const features = [
        { icon: '☕', title: 'Premium Beans', desc: 'Ethically sourced from the finest coffee regions around the world, ensuring the highest quality in every cup. We work directly with farmers to bring you the best.' },
        { icon: '👨‍🍳', title: 'Expert Craft', desc: 'Prepared with precision and passion by our skilled baristas who have mastered the art of coffee making. Every cup is a masterpiece of flavor and presentation.' },
        { icon: '❤️', title: 'Cozy Atmosphere', desc: 'A sanctuary for coffee lovers, designed to provide comfort and inspiration in every corner. The perfect place to work, relax, or connect with friends.' },
        { icon: '🌱', title: 'Sustainable', desc: 'Committed to environmental responsibility. We use eco-friendly packaging and support sustainable farming practices worldwide for a better future.' },
        { icon: '🎨', title: 'Artisan Quality', desc: 'Every item on our menu is crafted with attention to detail. From our signature drinks to our fresh pastries, quality is our top priority.' },
        { icon: '🌟', title: 'Award Winning', desc: 'Recognized for excellence in coffee making and customer service. Our commitment to quality has earned us multiple awards and recognition.' }
    ];

    return (
        <section id="about" className="section about" ref={ref}>
            <div className="container">
                <motion.h2
                    className="section-title"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8 }}
                >
                    Our Story
                </motion.h2>
                <motion.p
                    className="section-subtitle"
                    initial={{ opacity: 0, y: 50 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Born from a passion for exceptional coffee and warm hospitality. We've been serving 
                    the community for over a decade with dedication and excellence.
                </motion.p>
                <div className="about-grid">
                    {features.map((feature, index) => (
                        <AboutCard key={index} feature={feature} index={index} />
                    ))}
                </div>
            </div>
        </section>
    );
};

const AboutCard = ({ feature, index }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.3 });

    return (
        <motion.div
            ref={ref}
            className="about-card fade-in"
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: index * 0.1 }}
            whileHover={{ y: -12, scale: 1.02 }}
        >
            <motion.div
                className="about-icon"
                whileHover={{ scale: 1.15, rotate: 8 }}
            >
                {feature.icon}
            </motion.div>
            <h3>{feature.title}</h3>
            <p>{feature.desc}</p>
        </motion.div>
    );
};

export default About;

