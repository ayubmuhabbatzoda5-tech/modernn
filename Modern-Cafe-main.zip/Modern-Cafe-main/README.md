# Modern Cafe - Premium Coffee Experience

A beautiful, modern, and fully responsive landing page for a premium coffee cafe. Built with **React**, **Vite**, and **Framer Motion** with modern design.

## ✨ Features

- **Modern React Architecture** - Built with React 18 and Vite for optimal performance
- **Smooth Animations** - Powered by Framer Motion for fluid, professional animations
- **Component-Based** - Modular, reusable React components
- **Custom Hooks** - Reusable hooks for scroll progress, navbar state, and more
- **Modern Design** - Clean, elegant interface with glassmorphism effects and gradient animations
- **Fully Responsive** - Works perfectly on desktop, tablet, and mobile devices
- **Interactive Elements** - Hover effects, transitions, and micro-interactions

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ and npm/yarn/pnpm

### Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development server:**
   ```bash
   npm run dev
   ```

3. **Build for production:**
   ```bash
   npm run build
   ```

4. **Preview production build:**
   ```bash
   npm run preview
   ```

## 📁 Project Structure

```
Modern-Cafe-main/
├── src/
│   ├── components/      # React components
│   │   ├── About.jsx
│   │   ├── Awards.jsx
│   │   ├── Blog.jsx
│   │   ├── Contact.jsx
│   │   ├── Events.jsx
│   │   ├── FAQ.jsx
│   │   ├── Footer.jsx
│   │   ├── Gallery.jsx
│   │   ├── Hero.jsx
│   │   ├── LoadingScreen.jsx
│   │   ├── Menu.jsx
│   │   ├── Navigation.jsx
│   │   ├── Newsletter.jsx
│   │   ├── ProgressBar.jsx
│   │   ├── Team.jsx
│   │   └── Testimonials.jsx
│   ├── data/            # Data files
│   │   ├── awardsData.js
│   │   ├── blogData.js
│   │   ├── faqData.js
│   │   ├── menuData.js
│   │   └── teamData.js
│   ├── hooks/           # Custom React hooks
│   │   ├── useNavbarScroll.js
│   │   └── useScrollProgress.js
│   ├── styles/          # CSS files
│   │   └── index.css
│   ├── App.jsx          # Main App component
│   └── main.jsx         # Entry point
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## 🎨 Sections

- **Hero** - Eye-catching landing section with animated statistics
- **About** - Our story and features
- **Menu** - Interactive menu with search and category filters
- **Gallery** - Visual showcase of our cafe
- **Events** - Upcoming events and workshops
- **Testimonials** - Customer reviews
- **Blog** - Latest news and articles
- **Team** - Meet our team members
- **Awards** - Recognition and achievements
- **FAQ** - Frequently asked questions
- **Newsletter** - Email subscription
- **Contact** - Reservation form and contact information

## 🛠️ Technologies

- **React 18** - UI library
- **Vite** - Build tool and dev server
- **Framer Motion** - Animation library
- **CSS3** - Modern styling with gradients and glassmorphism

## 📱 Responsive Design

The website is fully responsive and optimized for:
- Desktop (1920px+)
- Laptop (1024px - 1919px)
- Tablet (768px - 1023px)
- Mobile (320px - 767px)

## 🎯 Performance

- Fast initial load
- Smooth animations
- Optimized images and assets
- Lazy loading for components

## 📄 License

This project is open source and available for personal and commercial use.

## 👨‍💻 Development

Made with ❤️ and ☕
